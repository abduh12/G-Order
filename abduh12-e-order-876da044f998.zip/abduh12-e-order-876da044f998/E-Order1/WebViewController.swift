//========================================================//  <~~~~
//  WebViewController.swift                               //
//  E-Order1                                              //
//                                                        //
//  Created by Abdhu Bafadhal on 9/7/17.                  //
//  Copyright © 2017 Abdhu Bafadhal. All rights reserved. //
// "http://129.144.188.148/gOrder/login"                  //
//========================================================//  <~~~~

import UIKit
import UserNotifications
import WebKit
import Foundation

class WebViewController: UIViewController, UIWebViewDelegate {
    @IBOutlet weak var myWebView: UIWebView!
    var delegate = UIApplication.shared.delegate as! AppDelegate
    let baseURL = "http://g-order.id"
    var preferences = UserDefaults.standard
    var currentSubscribeKey:String = ""
    var currentStatusKey:String = ""
    
    //memanggil fungsi checking internet connection
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        currentSubscribeKey = delegate.currentSubscribeKey
        currentStatusKey = delegate.currentStatusKey
        
        
        if Reachability.isConnectedToNetwork() == true {
            	
        } else {
            //let alertController = UIAlertController(title: "Tidak ada koneksi internet", message: "Cek koneksi internet anda..", preferredStyle: .alert)
            //let defaultAction = UIAlertAction(title: "Tutup", style: .default, handler: nil)
            //alertController.addAction(defaultAction)
            //present(alertController, animated: true, completion: nil)
        }
    }
    
    @IBAction func Produk(_ sender: Any) {
        let url = URL(string: "http://g-order.id")
        myWebView.loadRequest(URLRequest(url: url!))
    }
    
    @IBAction func Login(_ sender: Any) {
        let url = URL(string: "http://g-order.id/profile")
        myWebView.loadRequest(URLRequest(url: url!))
    }
    
    @IBAction func kembali(_ sender: Any) {
        myWebView.goBack()
    }
    
    @IBAction func buttonNotif(_ sender: Any) {
        //buat notifikasi kalo bisa ditaroh di function atau button
        let content = UNMutableNotificationContent()
        content.title = "udah mau habis waktunya"
        content.subtitle = "waktu"
        content.body = "the 5 second are ready"
        content.badge = 1
        
        //content cumik
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        let request = UNNotificationRequest(identifier: "timerDone", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(self.methodOfReceivedNotification(notification:)), name: NSNotification.Name(rawValue: "OpenLinkNotification"), object: nil)
        
        myWebView.delegate = self
        
        
        //nampilin web
        let url = URL(string: "\(baseURL)/login")
        myWebView.loadRequest(URLRequest(url: url!))
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func methodOfReceivedNotification(notification: NSNotification){
        let url = notification.object as! NSURL
        myWebView.loadRequest(URLRequest(url: url as URL))
    }
    
    
    func webViewDidFinishLoad(_ webView: UIWebView){
        
        // fill data
        let savedUsername = "USERNAME"
        let savedPassword = "PASSWORD"
        
        let fillForm = String(format: "document.getElementById('expert_email').value = '\(savedUsername)';document.getElementById('expert_password').value = '\(savedPassword)';")
        webView.stringByEvaluatingJavaScript(from: fillForm)
        
        //check checkboxes
        webView.stringByEvaluatingJavaScript(from: "document.getElementById('expert_remember_me').checked = true; document.getElementById('expert_terms_of_service').checked = true;")
        
        //submit form
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            webView.stringByEvaluatingJavaScript(from: "document.forms[\"new_expert\"].submit();")
        }
    
        let path = webView.request?.mainDocumentURL?.absoluteString
        switch path! {
        case "\(baseURL)/login":
            print("first time")
        case "\(baseURL)/home":
            let htmlString:String = webView.stringByEvaluatingJavaScript(from: "document.getElementById('user-email').innerHTML")!
            preferences.set("login", forKey: currentStatusKey)
            preferences.set(htmlString, forKey: currentSubscribeKey)
            delegate.pusher.nativePusher.subscribe(interestName: htmlString)
            print(htmlString)
            preferences.synchronize()
            
        default:
            print("others")
        }
    }
    
    
    func webView(_ webView: UIWebView,
                 shouldStartLoadWith request: URLRequest,
                 navigationType: UIWebViewNavigationType) -> Bool {
        let path = request.url!.absoluteString
        if (path == "\(baseURL)/logout") {
            if (preferences.object(forKey: currentStatusKey) != nil) {
                let currentStatus = preferences.object(forKey: currentStatusKey) as? String ?? ""
                if (currentStatus == "login") {
                    preferences.set("logout", forKey: currentStatusKey)
                    preferences.synchronize()
                }
            }
        }
        return true
    }
    
    
}

